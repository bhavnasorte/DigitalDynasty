package com.Emart.service;

public interface TransService {

	public String getUserId(String transId);
}
